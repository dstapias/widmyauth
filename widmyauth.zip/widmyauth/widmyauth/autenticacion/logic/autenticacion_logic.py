#from ..models import Autenticacion

#def get_adenda(identificador):
 #   adenda = Adenda.objects.get(identificador=identificador)
  #  return adenda